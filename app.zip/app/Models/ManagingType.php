<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ManagingType extends Model
{
    protected $table = 'managing_types';

    protected $fillable = [
        'name',
        'is_active',
    ];

    protected $casts = ['is_active' => 'boolean'];
}
